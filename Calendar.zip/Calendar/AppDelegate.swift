//
//  AppDelegate.swift
//  Calendar
//
//  Created by joshdemskie on 5/2/24.
//

import UIKit
import SwiftUI
import UserNotifications//allows us to send notifcations
class AppDelegate: NSObject, UIApplicationDelegate {
    //background
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {
        // mandates the user allow notifications on
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { granted, error in
            if let error = error {
                print("Error requesting notification authorization: \(error.localizedDescription)")
            }
        }
        
        return true
    }
}
