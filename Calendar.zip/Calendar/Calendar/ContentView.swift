//
//  ContentView.swift
//  Calendar
//
//  Created by joshua demskie on 4/28/2024
//
import UserNotifications
import SwiftUI

struct ContentView: View 
{
    @State private var reminderTitle = ""
    @State private var selectedDate = Date()
    @State private var reminders: [Reminder] = []
    
    var body: some View 
    {
        NavigationView
        {
            //input
            Form 
            {
                Section(header: Text("Add Reminder"))
                {
                    TextField("Title", text: $reminderTitle)
                    //uses calendar ui to choose a date
                    DatePicker("Date", selection: $selectedDate, displayedComponents: .date)
                }
                //add button
                Section 
                {
                    Button(action: addReminder)
                    {
                        Text("Add a Reminder")
                    }
                }
                
                Section(header: Text("Reminders")) 
                {
                    ForEach(reminders, id: \.title) { reminder in
                        Text("\(reminder.title) - \(reminder.date, formatter: dateFormatter)")
                    }
                }
            }
            .navigationTitle("Calendar App")
        }
    }
    
    func addReminder() 
    {
        let reminder = Reminder(title: reminderTitle, date: selectedDate)
        reminders.append(reminder)
        
        // creates the notifcation
        let content = UNMutableNotificationContent()
        content.title = reminder.title
        content.body = "Reminder for \(reminder.title) on \(reminder.date)"
        content.sound = UNNotificationSound.default
        
        let triggerDate = Calendar.current.dateComponents([.year, .month, .day, .hour, .minute, .second], from: reminder.date)
        let trigger = UNCalendarNotificationTrigger(dateMatching: triggerDate, repeats: false)
        //requests access to user notifications
        let request = UNNotificationRequest(identifier: UUID().uuidString, content: content, trigger: trigger)
        UNUserNotificationCenter.current().add(request)
        
        // Reset reminderTitle
        reminderTitle = ""
    }
}
//preview view
struct ContentView_Previews: PreviewProvider
{
    static var previews: some View 
    {
        ContentView()
    }
}

// Defines dateFormatter
let dateFormatter: DateFormatter =
{
    let formatter = DateFormatter()
    formatter.dateStyle = .long
    return formatter
}()
