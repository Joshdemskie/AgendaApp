//
//  Reminder.swift
//  Calendar
//
//  Created by user257650 on 4/28/24.
//

import Foundation
//creates skeleton for the reminder
struct Reminder
    {
    var title: String
    var date: Date
    }
